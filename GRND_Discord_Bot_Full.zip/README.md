# GRND-style Discord Bot (Discord only)

This bot is only for Discord. It does NOT connect to any game server.
The `/acc`, `/bans`, `/complaints`, `/jb`, and `/norma` commands search data saved in the bot's own `data/database.json` file. They do not fetch real game records automatically.

## Setup on Katabump
1. Upload and extract this ZIP into your bot's server directory.
2. Select Node.js 18.17+ (Node.js 22 is fine).
3. Copy `.env.example` to `.env`.
4. Fill in `DISCORD_TOKEN`, `CLIENT_ID`, `GUILD_ID`, and `OWNER_ID`.
   - `DISCORD_TOKEN`: token from Discord Developer Portal > Bot.
   - `CLIENT_ID`: Application ID from General Information.
   - `GUILD_ID`: your Discord server ID (recommended for fast test command registration).
   - `OWNER_ID`: your Discord user ID.
5. In Discord Developer Portal, enable the bot and invite it with `bot` and `applications.commands` scopes. It only needs basic bot access to the server.
6. In Katabump, install dependencies with `npm install`, then set startup command to `npm start` (or run `node index.js`).
7. Start the server. Check the console for `Ready: ...`.

## Commands
- `/setadmin member rank [server]` — add/update admin (server Administrator or configured bot owner only)
- `/admins` — numbered Discord mentions and ranks
- `/deleteadmin member` — remove admin entry
- `/acc gid global_id` — search local account records by Global ID
- `/acc name server nickname` — search local account records by server and nickname
- `/bans gid global_id` — search local ban records by Global ID
- `/bans player server nickname` — search local bans by server and nickname
- `/complaints [status]` — list complaints, optionally filtered by status
- `/jb [server]` — complaint counts/list, optionally filtered by server
- `/norma [server]` — saved admin playtime list
- `/data addaccount ...` — add an account record (Admin only)
- `/data addban ...` — add a ban record (Admin only)
- `/data addcomplaint ...` — add a complaint (Admin only)
- `/data setplaytime ...` — save/update admin playtime (Admin only)
- `/help` — command list

## Important
- This is a Discord-only starter bot with JSON storage. Game account, ban, complaint and playtime data must be added manually with `/data` commands.
- On some hosting services, local files can be reset when the container is reinstalled or recreated. Keep backups of `data/database.json`, or move to MongoDB later for more durable storage.
- Never share your bot token. If leaked, reset it in Discord Developer Portal.
