require('dotenv').config();
const {
  Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder,
  PermissionFlagsBits, EmbedBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID || '';
const OWNER_ID = process.env.OWNER_ID || '';

if (!TOKEN || !CLIENT_ID) {
  console.error('Missing DISCORD_TOKEN or CLIENT_ID in .env');
  process.exit(1);
}

const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'database.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

const EMPTY_DB = { admins: [], accounts: [], bans: [], complaints: [], playtime: [] };

function loadDB() {
  try {
    if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, JSON.stringify(EMPTY_DB, null, 2));
    const data = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    return { ...EMPTY_DB, ...data };
  } catch (error) {
    console.error('Database read error:', error.message);
    return JSON.parse(JSON.stringify(EMPTY_DB));
  }
}
let db = loadDB();
function saveDB() {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}
function same(a, b) { return String(a ?? '').trim().toLowerCase() === String(b ?? '').trim().toLowerCase(); }
function canManage(interaction) {
  return (OWNER_ID && interaction.user.id === OWNER_ID) ||
    Boolean(interaction.memberPermissions?.has(PermissionFlagsBits.Administrator));
}
async function managerOnly(interaction) {
  if (canManage(interaction)) return true;
  await interaction.reply({ content: '❌ এই command ব্যবহার করতে Server Administrator বা Bot Owner হতে হবে।', ephemeral: true });
  return false;
}
function embed(title, description, color = 0x5865F2) {
  return new EmbedBuilder().setTitle(title).setDescription(description || 'কোনো তথ্য পাওয়া যায়নি।').setColor(color).setTimestamp();
}
function cut(value, max = 300) {
  const s = String(value ?? '');
  return s.length > max ? s.slice(0, max - 3) + '...' : s;
}
function pages(lines, max = 3800) {
  const result = [];
  let current = '';
  for (const line of lines) {
    const candidate = current ? current + '\\n' + line : line;
    if (candidate.length > max && current) {
      result.push(current);
      current = line;
    } else current = candidate;
  }
  if (current) result.push(current);
  return result.length ? result : ['কোনো তথ্য পাওয়া যায়নি।'];
}
async function sendList(interaction, title, lines) {
  const allPages = pages(lines);
  await interaction.reply({ embeds: [embed(title, allPages[0])] });
  for (let i = 1; i < allPages.length; i++) {
    await interaction.followUp({ embeds: [embed(`${title} — ${i + 1}`, allPages[i])] });
  }
}

const commands = [
  new SlashCommandBuilder()
    .setName('setadmin').setDescription('Discord member-কে Admin list-এ যোগ বা update করুন')
    .addUserOption(o => o.setName('member').setDescription('যাকে Admin করবেন').setRequired(true))
    .addStringOption(o => o.setName('rank').setDescription('Admin rank').setRequired(true).setMaxLength(80))
    .addStringOption(o => o.setName('server').setDescription('Server name (optional)').setRequired(false).setMaxLength(80)),
  new SlashCommandBuilder().setName('admins').setDescription('Numbered Admin list দেখুন'),
  new SlashCommandBuilder().setName('deleteadmin').setDescription('Admin list থেকে member সরান (Admin only)')
    .addUserOption(o => o.setName('member').setDescription('যাকে সরাবেন').setRequired(true)),
  new SlashCommandBuilder().setName('acc').setDescription('Local account records খুঁজুন')
    .addSubcommand(s => s.setName('gid').setDescription('Global ID দিয়ে খুঁজুন')
      .addStringOption(o => o.setName('global_id').setDescription('Global ID').setRequired(true).setMaxLength(80)))
    .addSubcommand(s => s.setName('name').setDescription('Server + nickname দিয়ে খুঁজুন')
      .addStringOption(o => o.setName('server').setDescription('Server name').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('nickname').setDescription('Player nickname').setRequired(true).setMaxLength(80))),
  new SlashCommandBuilder().setName('bans').setDescription('Local ban records খুঁজুন')
    .addSubcommand(s => s.setName('gid').setDescription('Global ID দিয়ে খুঁজুন')
      .addStringOption(o => o.setName('global_id').setDescription('Global ID').setRequired(true).setMaxLength(80)))
    .addSubcommand(s => s.setName('player').setDescription('Server + nickname দিয়ে খুঁজুন')
      .addStringOption(o => o.setName('server').setDescription('Server name').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('nickname').setDescription('Player nickname').setRequired(true).setMaxLength(80))),
  new SlashCommandBuilder().setName('complaints').setDescription('Complaint list দেখুন')
    .addStringOption(o => o.setName('status').setDescription('Status filter').setRequired(false)
      .addChoices({ name: 'All', value: 'all' }, { name: 'Open', value: 'open' }, { name: 'Closed', value: 'closed' })),
  new SlashCommandBuilder().setName('jb').setDescription('Complaint count/list দেখুন')
    .addStringOption(o => o.setName('server').setDescription('Server filter (optional)').setRequired(false).setMaxLength(80)),
  new SlashCommandBuilder().setName('norma').setDescription('সংরক্ষিত Admin playtime দেখুন')
    .addStringOption(o => o.setName('server').setDescription('Server filter (optional)').setRequired(false).setMaxLength(80)),
  new SlashCommandBuilder().setName('help').setDescription('Bot command list দেখুন'),
  new SlashCommandBuilder().setName('data').setDescription('Local JSON records manage করুন (Admin only)')
    .addSubcommand(s => s.setName('addaccount').setDescription('Account record যোগ করুন')
      .addStringOption(o => o.setName('global_id').setDescription('Global ID').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('server').setDescription('Server name').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('nickname').setDescription('Nickname').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('extra').setDescription('Optional notes').setRequired(false).setMaxLength(500)))
    .addSubcommand(s => s.setName('addban').setDescription('Ban record যোগ করুন')
      .addStringOption(o => o.setName('global_id').setDescription('Global ID').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('server').setDescription('Server name').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('nickname').setDescription('Nickname').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('reason').setDescription('Ban reason').setRequired(true).setMaxLength(500))
      .addStringOption(o => o.setName('by').setDescription('Banned by').setRequired(true).setMaxLength(100)))
    .addSubcommand(s => s.setName('addcomplaint').setDescription('Complaint record যোগ করুন')
      .addStringOption(o => o.setName('player').setDescription('Player/complainant').setRequired(true).setMaxLength(100))
      .addStringOption(o => o.setName('server').setDescription('Server name').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('details').setDescription('Complaint details').setRequired(true).setMaxLength(1000))
      .addStringOption(o => o.setName('status').setDescription('Status').setRequired(false)
        .addChoices({ name: 'Open', value: 'open' }, { name: 'Closed', value: 'closed' })))
    .addSubcommand(s => s.setName('setplaytime').setDescription('Admin playtime যোগ/update করুন')
      .addUserOption(o => o.setName('member').setDescription('Discord Admin').setRequired(true))
      .addStringOption(o => o.setName('time').setDescription('যেমন 12h 30m').setRequired(true).setMaxLength(80))
      .addStringOption(o => o.setName('server').setDescription('Server name (optional)').setRequired(false).setMaxLength(80)))
].map(c => c.toJSON());

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(TOKEN);
  const route = GUILD_ID
    ? Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID)
    : Routes.applicationCommands(CLIENT_ID);
  await rest.put(route, { body: commands });
  console.log(`Registered ${commands.length} commands ${GUILD_ID ? 'to test guild' : 'globally'}.`);
}

client.once('ready', () => console.log(`Ready: ${client.user.tag}`));

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  try {
    const cmd = interaction.commandName;

    if (cmd === 'setadmin') {
      if (!(await managerOnly(interaction))) return;
      const user = interaction.options.getUser('member', true);
      const rank = interaction.options.getString('rank', true);
      const server = interaction.options.getString('server') || 'Not specified';
      const entry = db.admins.find(a => a.userId === user.id);
      if (entry) Object.assign(entry, { rank, server, updatedAt: new Date().toISOString() });
      else db.admins.push({ userId: user.id, rank, server, addedAt: new Date().toISOString() });
      saveDB();
      return interaction.reply({ embeds: [embed('✅ Admin saved', `${user} — **${rank}**\\nServer: **${server}**`)] });
    }

    if (cmd === 'deleteadmin') {
      if (!(await managerOnly(interaction))) return;
      const user = interaction.options.getUser('member', true);
      const before = db.admins.length;
      db.admins = db.admins.filter(a => a.userId !== user.id);
      saveDB();
      return interaction.reply({ content: before === db.admins.length ? 'এই member Admin list-এ নেই।' : `✅ ${user} Admin list থেকে সরানো হয়েছে।` });
    }

    if (cmd === 'admins') {
      const list = [...db.admins].sort((a, b) => String(a.rank).localeCompare(String(b.rank)));
      if (!list.length) return interaction.reply({ embeds: [embed('👮 Admins (0)', 'এখনো `/setadmin` দিয়ে কাউকে যোগ করা হয়নি।')] });
      return sendList(interaction, `👮 Admins (${list.length})`,
        list.map((a, i) => `**${i + 1}.** <@${a.userId}> — **${a.rank}** · Server: ${a.server || 'N/A'}`));
    }

    if (cmd === 'acc') {
      const sub = interaction.options.getSubcommand();
      let result;
      if (sub === 'gid') {
        const gid = interaction.options.getString('global_id', true);
        result = db.accounts.filter(a => same(a.globalId, gid));
      } else {
        const server = interaction.options.getString('server', true);
        const nickname = interaction.options.getString('nickname', true);
        result = db.accounts.filter(a => same(a.server, server) && same(a.nickname, nickname));
      }
      const lines = result.map((a, i) => `**${i + 1}.** GID: \`${a.globalId}\` · Server: **${a.server}** · Nick: **${a.nickname}**${a.extra ? `\\nNotes: ${cut(a.extra)}` : ''}`);
      return sendList(interaction, `🔎 Account Search (${result.length})`, lines);
    }

    if (cmd === 'bans') {
      const sub = interaction.options.getSubcommand();
      let result;
      if (sub === 'gid') {
        const gid = interaction.options.getString('global_id', true);
        result = db.bans.filter(b => same(b.globalId, gid));
      } else {
        const server = interaction.options.getString('server', true);
        const nickname = interaction.options.getString('nickname', true);
        result = db.bans.filter(b => same(b.server, server) && same(b.nickname, nickname));
      }
      const lines = result.map((b, i) => `**${i + 1}.** GID: \`${b.globalId}\` · **${b.nickname}** (${b.server})\\nReason: ${cut(b.reason)} · By: ${cut(b.by, 100)} · Date: ${b.date || 'N/A'}`);
      return sendList(interaction, `🔨 Ban Search (${result.length})`, lines);
    }

    if (cmd === 'complaints' || cmd === 'jb') {
      const status = cmd === 'complaints' ? (interaction.options.getString('status') || 'all') : 'all';
      const server = cmd === 'jb' ? interaction.options.getString('server') : null;
      const list = db.complaints.filter(c => (status === 'all' || same(c.status, status)) && (!server || same(c.server, server)));
      if (cmd === 'jb') {
        const open = list.filter(c => same(c.status, 'open')).length;
        const lines = [`Total: **${list.length}** · Open: **${open}** · Closed: **${list.length - open}**`,
          ...list.map((c, i) => `**${i + 1}.** #${c.id} · **${c.player}** (${c.server}) · ${c.status}\\n${cut(c.details, 220)}`)];
        return sendList(interaction, '📋 JB / Complaint Checker', lines);
      }
      const lines = list.map((c, i) => `**${i + 1}.** #${c.id} · **${c.player}** (${c.server}) · Status: **${c.status}**\\n${cut(c.details, 350)} · Date: ${c.date}`);
      return sendList(interaction, `📣 Complaints (${list.length})`, lines);
    }

    if (cmd === 'norma') {
      const server = interaction.options.getString('server');
      const list = db.playtime.filter(p => !server || same(p.server, server));
      const lines = list.map((p, i) => `**${i + 1}.** <@${p.userId}> — **${p.time}** · Server: ${p.server || 'Not specified'}`);
      return sendList(interaction, `⏱️ Admin Playtime (${list.length})`, lines);
    }

    if (cmd === 'help') {
      const help = [
        '`/setadmin member rank [server]` — Admin যোগ/update (Admin only)',
        '`/admins` — numbered Admin list with tags/ranks',
        '`/deleteadmin member` — Admin list থেকে সরানো (Admin only)',
        '`/acc gid global_id` — GID দিয়ে local account search',
        '`/acc name server nickname` — server + nickname search',
        '`/bans gid global_id` — GID দিয়ে local ban search',
        '`/bans player server nickname` — server + nickname ban search',
        '`/complaints [status]` — complaint list',
        '`/jb [server]` — complaint count/list',
        '`/norma [server]` — saved admin playtime list',
        '`/data addaccount ...` — account record add (Admin only)',
        '`/data addban ...` — ban record add (Admin only)',
        '`/data addcomplaint ...` — complaint record add (Admin only)',
        '`/data setplaytime ...` — playtime add/update (Admin only)',
        '`/help` — command list'
      ];
      return sendList(interaction, '🤖 GRND-style Bot Help', help);
    }

    if (cmd === 'data') {
      if (!(await managerOnly(interaction))) return;
      const sub = interaction.options.getSubcommand();
      if (sub === 'addaccount') {
        const globalId = interaction.options.getString('global_id', true);
        const server = interaction.options.getString('server', true);
        const nickname = interaction.options.getString('nickname', true);
        const extra = interaction.options.getString('extra') || '';
        db.accounts.push({ globalId, server, nickname, extra, date: new Date().toISOString(), addedBy: interaction.user.id });
        saveDB();
        return interaction.reply({ content: `✅ Account saved: GID \`${globalId}\` · ${nickname} (${server})` });
      }
      if (sub === 'addban') {
        const globalId = interaction.options.getString('global_id', true);
        const server = interaction.options.getString('server', true);
        const nickname = interaction.options.getString('nickname', true);
        const reason = interaction.options.getString('reason', true);
        const by = interaction.options.getString('by', true);
        db.bans.push({ globalId, server, nickname, reason, by, date: new Date().toISOString().slice(0, 10), addedBy: interaction.user.id });
        saveDB();
        return interaction.reply({ content: `✅ Ban saved: GID \`${globalId}\` · ${nickname}` });
      }
      if (sub === 'addcomplaint') {
        const player = interaction.options.getString('player', true);
        const server = interaction.options.getString('server', true);
        const details = interaction.options.getString('details', true);
        const status = interaction.options.getString('status') || 'open';
        const id = db.complaints.length ? Math.max(...db.complaints.map(c => Number(c.id) || 0)) + 1 : 1;
        db.complaints.push({ id, player, server, details, status, date: new Date().toISOString().slice(0, 10), addedBy: interaction.user.id });
        saveDB();
        return interaction.reply({ content: `✅ Complaint #${id} saved (${status}).` });
      }
      if (sub === 'setplaytime') {
        const user = interaction.options.getUser('member', true);
        const time = interaction.options.getString('time', true);
        const server = interaction.options.getString('server') || 'Not specified';
        const old = db.playtime.find(p => p.userId === user.id && same(p.server, server));
        if (old) Object.assign(old, { time, updatedAt: new Date().toISOString() });
        else db.playtime.push({ userId: user.id, time, server, updatedAt: new Date().toISOString() });
        saveDB();
        return interaction.reply({ content: `✅ ${user}-এর playtime **${time}** saved.` });
      }
    }
  } catch (error) {
    console.error(`/${interaction.commandName} error:`, error);
    const reply = { content: '❌ Command-এ সমস্যা হয়েছে। Katabump Console-এর error দেখুন।', ephemeral: true };
    if (interaction.replied || interaction.deferred) await interaction.followUp(reply).catch(() => {});
    else await interaction.reply(reply).catch(() => {});
  }
});

(async () => {
  try {
    await registerCommands();
    await client.login(TOKEN);
  } catch (error) {
    console.error('Startup error:', error);
    process.exit(1);
  }
})();
